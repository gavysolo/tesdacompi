﻿Imports System.Data.SqlClient
Module cpmstring
    Friend constr As String = "Server=NEKOSKI\nekoski;Initial Catalog=Module1;User=sa,Password=newpassword"
    Friend con As New SqlConnection(constr)
    Friend com As New SqlCommand


End Module
